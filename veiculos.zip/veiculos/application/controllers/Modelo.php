<?php

class Modelo extends CI_Controller{

    public function index(){

        $crud= new Grocery_CRUD();
        $crud->set_table('modelo');
        $crud->set_subject('modelo');

        $output = $crud->render();
        $this->load->view('example.php',$output);

    }

}

?>